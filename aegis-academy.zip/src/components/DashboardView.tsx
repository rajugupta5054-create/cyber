import { useState, useEffect } from "react";
import { 
  TrendingUp, 
  Star, 
  Award, 
  Shield, 
  Play, 
  Lock, 
  Info, 
  AlertTriangle, 
  Zap, 
  Terminal, 
  Activity, 
  Clock, 
  CheckCircle2, 
  RotateCcw 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface DashboardViewProps {
  onNavigate: (tab: "landing" | "privacy-module" | "dashboard") => void;
}

export default function DashboardView({ onNavigate }: DashboardViewProps) {
  // States for interactive engagement
  const [xp, setXp] = useState(12240);
  const [missionsCompleted, setMissionsCompleted] = useState(12);
  const [isXpDoubled, setIsXpDoubled] = useState(false);
  const [activeSimulationLog, setActiveSimulationLog] = useState<string[]>([]);
  const [simulationRunning, setSimulationRunning] = useState(false);
  const [simulationProgress, setSimulationProgress] = useState(0);

  // Time ticker
  const [systemTime, setSystemTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toISOString().split("T")[1].split(".")[0];
      setSystemTime(`System Time: ${timeStr} UTC`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulation handler for Zero-Day Detection
  const handleLaunchSimulation = () => {
    if (simulationRunning) return;
    setSimulationRunning(true);
    setSimulationProgress(0);
    setActiveSimulationLog(["Initializing localized containment shell...", "Pre-loading heuristics databases..."]);

    const simLogs = [
      "Hooking into standard event streams...",
      "Analyzing active telemetry logs...",
      "Warning: Outlier packet payload pattern detected at 10.0.12.92",
      "Parsing binary signature structure...",
      "Matching signature against known CVE registry...",
      "Zero-Day vulnerability identified in auth-controller.ts",
      "Deploying secure micro-patch container...",
      "Sandbox quarantine established. Threat completely neutralized."
    ];

    let step = 0;
    const interval = setInterval(() => {
      step += 1;
      const progress = Math.min(step * 12.5, 100);
      setSimulationProgress(progress);

      if (step <= simLogs.length) {
        setActiveSimulationLog(prev => [...prev, `[SIM] > ${simLogs[step - 1]}`]);
      }

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setSimulationRunning(false);
          // Reward the operator!
          if (!isXpDoubled) {
            setXp(prev => prev + 450);
          } else {
            setXp(prev => prev + 900);
          }
          if (missionsCompleted < 15) {
            setMissionsCompleted(prev => prev + 1);
          }
          setActiveSimulationLog(prev => [...prev, "✓ SIMULATION COMPLETE: Operator rewarded with XP."]);
        }, 800);
      }
    }, 450);
  };

  const handleJoinDoubleXp = () => {
    setIsXpDoubled(true);
  };

  // Profile levels derived
  const level = Math.floor(xp / 300) + 2; 
  const currentLevelXp = xp % 300;
  const progressPercent = Math.min(Math.floor((currentLevelXp / 300) * 100), 100);

  return (
    <div className="relative">
      {/* Top Banner Stats / Profile summary */}
      <section className="mb-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="font-display text-4xl font-extrabold tracking-tight mb-2">Operator Dashboard</h1>
            <div className="flex flex-wrap items-center gap-4">
              <span className="bg-primary/10 border border-primary/30 text-primary px-3 py-1 rounded-full font-mono text-[10px] uppercase tracking-[0.2em] flex items-center gap-2 font-semibold">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                Rank: Sentinel
              </span>
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-on-surface-variant/85 font-semibold">XP Level {level}</span>
                <div className="w-44 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-primary to-secondary rounded-full shadow-[0_0_8px_#60a5fa] transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
                <span className="font-mono text-xs text-primary font-bold">{progressPercent}%</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-on-surface-variant bg-surface-container/40 px-3 py-2 rounded-lg border border-white/5 font-mono text-xs">
            <Clock className="w-4 h-4 text-primary" />
            <span>{systemTime || "System Time: Loading..."}</span>
          </div>
        </div>
      </section>

      {/* Bento Grid Stats */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {/* Missions Completed */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col items-center justify-center text-center relative group">
          <p className="font-mono text-xs text-on-surface-variant/80 mb-6 uppercase tracking-wider font-semibold">Missions Completed</p>
          <div className="relative w-32 h-32 flex items-center justify-center mb-4">
            <svg className="w-full h-full -rotate-90">
              <circle cx="64" cy="64" fill="transparent" r="56" stroke="rgba(255,255,255,0.05)" strokeWidth="6"></circle>
              <circle 
                cx="64" 
                cy="64" 
                fill="transparent" 
                r="56" 
                stroke="url(#blueGrad)" 
                strokeDasharray="351.8" 
                strokeDashoffset={351.8 - (351.8 * (missionsCompleted / 15))} 
                strokeLinecap="round" 
                strokeWidth="6"
                className="transition-all duration-1000"
              ></circle>
              <defs>
                <linearGradient id="blueGrad" x1="0%" x2="100%" y1="0%" y2="100%">
                  <stop offset="0%" stopColor="#a4c9ff" stopOpacity="1" />
                  <stop offset="100%" stopColor="#60a5fa" stopOpacity="1" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-display text-2xl font-bold text-primary">{missionsCompleted}/15</span>
            </div>
          </div>
          <p className="font-mono text-[11px] text-on-surface-variant/65 italic">
            {15 - missionsCompleted} simulations until next promotion
          </p>
        </div>

        {/* Threats Neutralized */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <p className="font-mono text-xs text-on-surface-variant/80 mb-2 uppercase tracking-wider font-semibold">Threats Neutralized</p>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="font-display text-4xl font-extrabold text-primary">142</span>
              <span className="text-tertiary text-xs flex items-center gap-1 font-bold">
                <TrendingUp className="w-3.5 h-3.5" />
                +12%
              </span>
            </div>
          </div>
          {/* Sparkline Weekly Chart Placeholder */}
          <div className="h-16 w-full flex items-end gap-1.5 mt-4">
            <div className="w-full bg-primary/10 h-[35%] rounded-sm hover:bg-primary/25 transition-colors"></div>
            <div className="w-full bg-primary/10 h-[60%] rounded-sm hover:bg-primary/25 transition-colors"></div>
            <div className="w-full bg-primary/15 h-[45%] rounded-sm hover:bg-primary/25 transition-colors"></div>
            <div className="w-full bg-primary/15 h-[80%] rounded-sm hover:bg-primary/25 transition-colors"></div>
            <div className="w-full bg-primary/20 h-[65%] rounded-sm hover:bg-primary/25 transition-colors border-t border-primary/30"></div>
            <div className="w-full bg-primary/20 h-[50%] rounded-sm hover:bg-primary/25 transition-colors"></div>
            <div className="w-full bg-primary/40 h-[92%] rounded-sm hover:bg-primary/55 transition-all border-t border-primary/50 shadow-[0_0_8px_rgba(164,201,255,0.2)]"></div>
          </div>
          <div className="flex justify-between mt-2 font-mono text-[9px] text-on-surface-variant/50">
            <span>MON</span><span>SUN</span>
          </div>
        </div>

        {/* Accuracy Rating */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between">
          <p className="font-mono text-xs text-on-surface-variant/80 mb-4 uppercase tracking-wider font-semibold">Accuracy Rating</p>
          <div className="flex flex-col items-center justify-center my-auto">
            <div className="text-5xl font-extrabold leading-none font-display text-transparent bg-gradient-to-r from-primary to-secondary bg-clip-text glow-text">
              94%
            </div>
            <div className="mt-4 flex gap-1 text-primary">
              <Star className="w-4 h-4 fill-primary" />
              <Star className="w-4 h-4 fill-primary" />
              <Star className="w-4 h-4 fill-primary" />
              <Star className="w-4 h-4 fill-primary" />
              <Star className="w-4 h-4 text-on-surface-variant/30" />
            </div>
          </div>
          <div className="mt-4 font-mono text-[11px] text-primary/80 border-t border-white/5 pt-3 text-center">
            Elite precision confirmed
          </div>
        </div>

        {/* Global Rank Widget */}
        <div className="glass-panel rounded-2xl p-6 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <p className="font-mono text-xs text-on-surface-variant/80 uppercase tracking-wider font-semibold">Global Rank</p>
            <span className="text-primary font-bold text-sm">#412</span>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-1.5 rounded bg-white/5 border border-white/5 text-[11px]">
              <div className="flex items-center gap-2 text-on-surface-variant">
                <span>410</span>
                <span className="font-medium text-on-surface">V_Ghost</span>
              </div>
              <span className="font-mono text-primary-container font-semibold">12,450 XP</span>
            </div>
            
            <div className="flex items-center justify-between p-1.5 rounded bg-primary/10 border border-primary/20 text-[11px] shadow-[0_0_8px_rgba(164,201,255,0.05)]">
              <div className="flex items-center gap-2 text-primary font-bold">
                <span>412</span>
                <span>You (Sentinel)</span>
              </div>
              <span className="font-mono font-bold text-primary">{xp.toLocaleString()} XP</span>
            </div>

            <div className="flex items-center justify-between p-1.5 rounded bg-white/5 border border-white/5 text-[11px] opacity-60">
              <div className="flex items-center gap-2 text-on-surface-variant">
                <span>413</span>
                <span className="font-medium text-on-surface">ZeroLog</span>
              </div>
              <span className="font-mono text-primary-container font-semibold">12,190 XP</span>
            </div>
          </div>
          <button className="w-full mt-3 text-[10px] font-mono text-primary uppercase tracking-widest flex items-center justify-center gap-1 hover:gap-3 transition-all cursor-pointer">
            Full Leaderboard <TrendingUp className="w-3 h-3" />
          </button>
        </div>
      </section>

      {/* Sentinel Overview & Active Missions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Missions column */}
        <section className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl md:text-2xl font-semibold text-on-surface">Active Missions</h2>
            <button className="text-primary font-mono text-xs uppercase hover:underline cursor-pointer">Browse All</button>
          </div>

          <div className="space-y-4">
            {/* Zero-Day Detection Card */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6 group hover:bg-white/[0.04] transition-all border-l-4 border-l-primary">
              <div className="flex gap-5 items-start md:items-center">
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-105 transition-transform shrink-0">
                  <Activity className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <h3 className="font-display text-lg font-bold text-on-surface">Zero-Day Detection</h3>
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-tertiary/10 text-tertiary border border-tertiary/20">In Progress</span>
                  </div>
                  <p className="text-on-surface-variant text-xs max-w-md leading-relaxed opacity-90">
                    Identify and quarantine emerging vulnerabilities within simulated container environments.
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
                <div className="text-left md:text-right">
                  <p className="font-mono text-[9px] text-on-surface-variant uppercase tracking-wider mb-1">Difficulty</p>
                  <div className="flex gap-1">
                    <div className="w-3.5 h-1 rounded-full bg-primary"></div>
                    <div className="w-3.5 h-1 rounded-full bg-primary"></div>
                    <div className="w-3.5 h-1 rounded-full bg-primary"></div>
                    <div className="w-3.5 h-1 rounded-full bg-white/10"></div>
                    <div className="w-3.5 h-1 rounded-full bg-white/10"></div>
                  </div>
                </div>
                <button 
                  onClick={handleLaunchSimulation}
                  disabled={simulationRunning}
                  className={`px-5 py-2.5 bg-gradient-to-r from-primary to-secondary text-on-primary font-bold rounded-xl flex items-center justify-center gap-2 hover:scale-105 transition-transform cursor-pointer ${simulationRunning ? "opacity-40 cursor-not-allowed" : "shadow-lg shadow-primary/10"}`}
                >
                  <Play className="w-4 h-4 fill-on-primary" />
                  <span className="text-xs">{simulationRunning ? "Running" : "Launch"}</span>
                </button>
              </div>
            </div>

            {/* Zero-day running interactive console */}
            <AnimatePresence>
              {(simulationRunning || activeSimulationLog.length > 0) && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="rounded-xl overflow-hidden border border-white/10 bg-black/80 font-mono text-xs p-4"
                >
                  <div className="flex justify-between items-center border-b border-white/5 pb-2 mb-3">
                    <span className="text-primary flex items-center gap-2 font-bold">
                      <Terminal className="w-3.5 h-3.5" />
                      SIMULATION CONTAINER // LOG_STREAM
                    </span>
                    {simulationRunning && (
                      <span className="text-on-surface-variant animate-pulse">{simulationProgress}%</span>
                    )}
                  </div>
                  <div className="max-h-36 overflow-y-auto space-y-1 scrollbar-thin select-none">
                    {activeSimulationLog.map((log, i) => (
                      <p key={i} className="text-on-surface-variant opacity-80">{log}</p>
                    ))}
                  </div>
                  {!simulationRunning && activeSimulationLog.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-white/5 text-right">
                      <button 
                        onClick={() => setActiveSimulationLog([])}
                        className="text-[10px] text-on-surface-variant hover:text-primary transition-colors cursor-pointer"
                      >
                        Clear Simulation Terminal
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Advanced SQLi Card (Locked) */}
            <div className="glass-panel p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6 opacity-60 relative overflow-hidden group">
              <div className="absolute inset-0 bg-black/10 backdrop-blur-[1px] z-10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs font-mono bg-black/85 px-4 py-2 rounded-lg border border-white/10">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Requires Level 45</span>
                </div>
              </div>
              <div className="flex gap-5 items-start md:items-center">
                <div className="w-14 h-14 rounded-xl bg-white/5 flex items-center justify-center text-on-surface-variant shrink-0">
                  <Lock className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <h3 className="font-display text-lg font-bold text-on-surface">Advanced SQLi Protection</h3>
                    <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-white/10 text-on-surface-variant border border-white/10">Locked</span>
                  </div>
                  <p className="text-on-surface-variant text-xs max-w-md leading-relaxed opacity-90">
                    Master manual bind SQL injection safeguards against highly customized WAF structures.
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
                <div className="text-left md:text-right">
                  <p className="font-mono text-[9px] text-on-surface-variant uppercase tracking-wider mb-1">Difficulty</p>
                  <div className="flex gap-1">
                    <div className="w-3.5 h-1 rounded-full bg-error"></div>
                    <div className="w-3.5 h-1 rounded-full bg-error"></div>
                    <div className="w-3.5 h-1 rounded-full bg-error"></div>
                    <div className="w-3.5 h-1 rounded-full bg-error"></div>
                    <div className="w-3.5 h-1 rounded-full bg-error"></div>
                  </div>
                </div>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center border border-white/10 text-on-surface-variant">
                  <Lock className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Sentinel Overview column */}
        <section className="space-y-6">
          <h2 className="font-display text-xl md:text-2xl font-semibold">Sentinel Overview</h2>
          
          {/* Core Competencies panel */}
          <div className="glass-panel p-6 rounded-2xl">
            <p className="font-mono text-xs text-on-surface-variant/80 uppercase tracking-wider mb-5 font-semibold">Core Competencies</p>
            <div className="space-y-5">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-on-surface font-medium">Network Defense</span>
                  <span className="text-primary font-bold">92%</span>
                </div>
                <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full shadow-[0_0_10px_#a4c9ff]" style={{ width: "92%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-on-surface font-medium">Offensive Security</span>
                  <span className="text-secondary font-bold">78%</span>
                </div>
                <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-secondary rounded-full shadow-[0_0_10px_#cebdff]" style={{ width: "78%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-on-surface font-medium">Cloud Security Safeguards</span>
                  <span className="text-primary-container font-bold">65%</span>
                </div>
                <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-primary-container rounded-full shadow-[0_0_10px_#60a5fa]" style={{ width: "65%" }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Latest Intel Alerts Feed */}
          <div className="glass-panel p-6 rounded-2xl relative overflow-hidden">
            <span className="material-symbols-outlined absolute -bottom-6 -right-6 text-[110px] opacity-[0.03] text-primary">security</span>
            <p className="font-mono text-xs text-on-surface-variant/80 uppercase tracking-wider mb-4 font-semibold">Latest Intel</p>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-white/[0.03] border-l-2 border-primary border-y border-r border-white/5">
                <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-on-surface font-semibold mb-1">System Update</p>
                  <p className="text-[11px] text-on-surface-variant/85 leading-relaxed">
                    New 'Kernel Exploitation' simulation launched in the Threat Lab. Limited entry clearances.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-lg bg-white/[0.03] border-l-2 border-tertiary border-y border-r border-white/5">
                <AlertTriangle className="w-4 h-4 text-tertiary shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-on-surface font-semibold mb-1">Leaderboard Shift</p>
                  <p className="text-[11px] text-on-surface-variant/85 leading-relaxed">
                    Operator-X just climbed 5 spots. Your position is at risk in the Sentinel elite division.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Double XP Event Interactive Banner */}
          <div className="bg-primary/10 border border-primary/25 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-on-primary">
                <Zap className="w-5 h-5 fill-on-primary" />
              </div>
              <div>
                <p className="text-xs font-bold text-on-surface uppercase tracking-wider">Double XP Event</p>
                <p className="text-[9px] text-on-surface-variant/85 uppercase tracking-widest font-mono">
                  {isXpDoubled ? "ACTIVE ON CONTAINER" : "ENDS IN 02:45:11"}
                </p>
              </div>
            </div>
            <button 
              onClick={handleJoinDoubleXp}
              disabled={isXpDoubled}
              className={`text-[10px] font-bold px-4 py-2 rounded-lg uppercase tracking-wider cursor-pointer ${isXpDoubled ? "bg-primary/20 text-primary border border-primary/30" : "bg-primary text-on-primary hover:bg-primary/90"}`}
            >
              {isXpDoubled ? "Joined" : "Join"}
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

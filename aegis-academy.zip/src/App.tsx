import { useState } from "react";
import { 
  Shield, 
  Bell, 
  User, 
  Terminal, 
  Settings, 
  HelpCircle, 
  LogOut, 
  Menu, 
  X, 
  Layers, 
  Cpu, 
  Database,
  Compass,
  ArrowRight,
  Flame,
  CheckCircle,
  AlertOctagon,
  Radar
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ShaderCanvas from "./components/ShaderCanvas";
import LandingView from "./components/LandingView";
import PrivacyModuleView from "./components/PrivacyModuleView";
import DashboardView from "./components/DashboardView";
import { AppTab } from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>("landing");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeOperator, setActiveOperator] = useState<"operator-01" | "operator-07">("operator-07");

  // Operator constant configurations
  const operators = {
    "operator-01": {
      name: "Operator-01",
      rank: "Sentinel",
      levelText: "Rank: Sentinel",
      avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuAhtrNwyA-75HnyIeGPwfO4WE3jHYfF_vPo4PsxWbSeF4cLohuYKdWTXN6Iv13ihC-6s0v08x7tZoIUcY54Yy8t_wJY3x4bc6PLqoFfSxNzgkNtfh7sl-7S4LIUQ8n_SkYRVzPrdGfnwmRT9d1_NRvAAD1y5VP_CfNCC5yHCOv0ksFvz_UrDYkomIq8qn0L9xLaKX5G1i1Zm159X0DNGEtPS5GY27yHBLKvxtgZ2nuyjHeKWTpIbvFJm5Z_icCuzgB7_pSVRf0l23Jz",
      threatLevel: "Sentinel"
    },
    "operator-07": {
      name: "Operator-07",
      rank: "Sentinel",
      levelText: "Threat Level: Low",
      avatar: "https://lh3.googleusercontent.com/aida-public/AB6AXuCOe1iFfE14sH6qSM2vRNyWjgd_QrN9oiHHLZqtdSNUK1xbTeo7aHlTQIUjoo9_GJKUja-IbiwbRxVGb_GifS_90iRERssw637CJt5f9IJ4lem8fuPlzy7RywMcoCr5b3ADzb73E9TS0GnxboeLgr6xWUABKMG1QuPU0d91bfMyan6ihcbgVb000BxvFjp-qyKvQXpCO4_YpgLt4ETefAzvmF41EK6l96QCUAs-IvmYGRYNUZxqok2tQ0AHz3fROO0W5UJ-pRnj62PU",
      threatLevel: "Low"
    }
  };

  const currentOperator = operators[activeOperator];

  const handleNavigate = (tab: AppTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    // Auto sync operator profiles based on module selection
    if (tab === "privacy-module") {
      setActiveOperator("operator-01");
    } else if (tab === "dashboard") {
      setActiveOperator("operator-07");
    }
  };

  const toggleOperatorProfile = () => {
    setActiveOperator(prev => prev === "operator-01" ? "operator-07" : "operator-01");
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-on-surface select-none overflow-hidden font-sans">
      
      {/* Background shader canvas */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <ShaderCanvas />
        <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/70 to-background"></div>
      </div>

      {/* Top Header Navigation */}
      <header className="fixed top-0 left-0 right-0 h-20 z-50 bg-surface/30 backdrop-blur-md border-b border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.2)]">
        <div className="flex justify-between items-center h-full px-6 md:px-12 max-w-7xl mx-auto">
          
          {/* Logo */}
          <div 
            onClick={() => handleNavigate("landing")}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <div className="absolute -inset-1.5 bg-primary/20 blur-md rounded-full group-hover:bg-primary/45 transition-all"></div>
              <Shield className="w-8 h-8 text-primary relative drop-shadow-[0_0_8px_rgba(164,201,255,0.45)]" />
            </div>
            <span className="font-display text-xl md:text-2xl font-bold tracking-tighter text-primary">
              Aegis Academy
            </span>
          </div>

          {/* Desktop Nav links */}
          <nav className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => handleNavigate("privacy-module")}
              className={`font-display text-sm font-semibold tracking-wide transition-all cursor-pointer pb-1 border-b-2 ${activeTab === "privacy-module" ? "text-primary border-primary" : "text-on-surface-variant hover:text-on-surface border-transparent"}`}
            >
              Modules
            </button>
            <button 
              onClick={() => handleNavigate("landing")}
              className={`font-display text-sm font-semibold tracking-wide transition-all cursor-pointer pb-1 border-b-2 ${activeTab === "landing" ? "text-primary border-primary" : "text-on-surface-variant hover:text-on-surface border-transparent"}`}
            >
              Simulations
            </button>
            <button 
              onClick={() => handleNavigate("dashboard")}
              className={`font-display text-sm font-semibold tracking-wide transition-all cursor-pointer pb-1 border-b-2 ${activeTab === "dashboard" ? "text-primary border-primary" : "text-on-surface-variant hover:text-on-surface border-transparent"}`}
            >
              Operator Dashboard
            </button>
            <button 
              onClick={() => handleNavigate("landing")}
              className="font-display text-sm font-semibold tracking-wide text-on-surface-variant hover:text-on-surface transition-all cursor-pointer pb-1 border-b-2 border-transparent"
            >
              Leaderboard
            </button>
          </nav>

          {/* User Controls Right Panel */}
          <div className="flex items-center gap-4">
            {/* Quick Profile switcher */}
            <button 
              onClick={toggleOperatorProfile}
              title="Switch Operator Profile View"
              className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-mono text-on-surface-variant hover:text-primary hover:border-primary/40 transition-all cursor-pointer"
            >
              <span>{activeOperator === "operator-01" ? "Active: Op-01" : "Active: Op-07"}</span>
            </button>

            <button className="p-2 text-on-surface-variant hover:text-primary hover:bg-white/5 rounded-full transition-all cursor-pointer">
              <Bell className="w-5 h-5" />
            </button>

            <button className="p-2 text-on-surface-variant hover:text-primary hover:bg-white/5 rounded-full transition-all cursor-pointer">
              <Shield className="w-5 h-5" />
            </button>

            {/* Profile Avatar */}
            <div 
              onClick={() => handleNavigate("dashboard")}
              className="w-10 h-10 rounded-full border border-primary/20 hover:border-primary/60 overflow-hidden cursor-pointer active:scale-95 transition-all shadow-[0_0_10px_rgba(164,201,255,0.15)]"
            >
              <img 
                className="w-full h-full object-cover" 
                alt="Operator Portrait" 
                src={currentOperator.avatar}
              />
            </div>

            {/* Mobile Menu button */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-on-surface-variant hover:text-on-surface"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-x-0 top-20 z-40 bg-surface-dim border-b border-white/10 p-6 flex flex-col gap-4 shadow-2xl backdrop-blur-xl md:hidden"
          >
            <button 
              onClick={() => handleNavigate("privacy-module")}
              className={`w-full py-2.5 text-left font-display font-semibold ${activeTab === "privacy-module" ? "text-primary" : "text-on-surface-variant"}`}
            >
              Modules
            </button>
            <button 
              onClick={() => handleNavigate("landing")}
              className={`w-full py-2.5 text-left font-display font-semibold ${activeTab === "landing" ? "text-primary" : "text-on-surface-variant"}`}
            >
              Simulations
            </button>
            <button 
              onClick={() => handleNavigate("dashboard")}
              className={`w-full py-2.5 text-left font-display font-semibold ${activeTab === "dashboard" ? "text-primary" : "text-on-surface-variant"}`}
            >
              Operator Dashboard
            </button>
            <div className="h-px bg-white/10 my-1"></div>
            <div className="flex justify-between items-center">
              <span className="text-xs font-mono text-on-surface-variant">Profile View</span>
              <button 
                onClick={toggleOperatorProfile}
                className="px-3 py-1.5 rounded bg-white/5 border border-white/10 text-xs text-primary"
              >
                {activeOperator === "operator-01" ? "Operator-01" : "Operator-07"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Body Content & Sidebar Layout */}
      <div className="flex-grow flex pt-20 relative z-10">
        
        {/* Dynamic Sidebar - Shown ONLY on Dashboard and Privacy Module Views */}
        {activeTab !== "landing" && (
          <aside className="hidden lg:flex flex-col w-64 fixed left-0 top-20 bottom-0 bg-surface-dim/40 backdrop-blur-xl border-r border-white/10 p-6 flex-shrink-0 justify-between">
            <div className="space-y-6">
              {/* Sidenav Operator Details Card */}
              <div 
                onClick={toggleOperatorProfile}
                className="flex items-center gap-3 p-2.5 rounded-xl bg-white/5 border border-white/5 hover:border-primary/20 cursor-pointer transition-all"
              >
                <div className="w-11 h-11 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <User className="w-6 h-6 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="font-display font-bold text-primary text-sm truncate leading-tight">
                    {currentOperator.name}
                  </p>
                  <p className="font-mono text-[10px] text-on-surface-variant opacity-70 leading-none mt-1">
                    {currentOperator.levelText}
                  </p>
                </div>
              </div>

              {/* Sidenav navigation */}
              <nav className="space-y-1">
                <button 
                  onClick={() => handleNavigate("dashboard")}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-lg text-sm font-semibold transition-all cursor-pointer ${activeTab === "dashboard" ? "bg-primary/10 text-primary border-r-4 border-primary font-bold" : "text-on-surface-variant hover:bg-white/5 hover:text-on-surface"}`}
                >
                  <Cpu className="w-4 h-4" />
                  <span>Command Center</span>
                </button>

                <button 
                  onClick={() => handleNavigate("privacy-module")}
                  className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-lg text-sm font-semibold transition-all cursor-pointer ${activeTab === "privacy-module" ? "bg-primary/10 text-primary border-r-4 border-primary font-bold" : "text-on-surface-variant hover:bg-white/5 hover:text-on-surface"}`}
                >
                  <Terminal className="w-4 h-4" />
                  <span>Threat Intelligence</span>
                </button>

                <button 
                  onClick={() => handleNavigate("landing")}
                  className="w-full flex items-center gap-3.5 px-4 py-3 rounded-lg text-sm font-semibold text-on-surface-variant hover:bg-white/5 hover:text-on-surface transition-all cursor-pointer"
                >
                  <Layers className="w-4 h-4" />
                  <span>System Terminals</span>
                </button>

                <button className="w-full flex items-center gap-3.5 px-4 py-3 rounded-lg text-sm font-semibold text-on-surface-variant hover:bg-white/5 hover:text-on-surface transition-all cursor-pointer">
                  <Settings className="w-4 h-4" />
                  <span>Academy Settings</span>
                </button>
              </nav>
            </div>

            {/* Bottom Sidenav links */}
            <div className="space-y-1 border-t border-white/5 pt-4">
              <button 
                onClick={() => handleNavigate("landing")}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-semibold text-on-surface-variant hover:text-primary transition-all cursor-pointer"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Help Center</span>
              </button>
              <button 
                onClick={() => handleNavigate("landing")}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-semibold text-on-surface-variant hover:text-error transition-all cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </aside>
        )}

        {/* Dynamic content rendering with slide up transitions */}
        <main className={`flex-grow px-6 py-10 md:px-12 max-w-7xl mx-auto w-full transition-all duration-300 ${activeTab !== "landing" ? "lg:ml-64" : ""}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
            >
              {activeTab === "landing" && (
                <LandingView onNavigate={handleNavigate} />
              )}
              {activeTab === "privacy-module" && (
                <PrivacyModuleView />
              )}
              {activeTab === "dashboard" && (
                <DashboardView onNavigate={handleNavigate} />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Global Bottom Footer */}
      <footer className={`w-full relative z-10 bg-surface-container-lowest/80 backdrop-blur-md mt-auto border-t border-white/5 transition-all duration-300 ${activeTab !== "landing" ? "lg:pl-64" : ""}`}>
        <div className="flex flex-col md:flex-row justify-between items-center px-6 md:px-12 py-8 max-w-7xl mx-auto gap-4">
          <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-left">
            <span className="font-mono text-xs text-primary font-semibold tracking-wider">AEGIS ACADEMY DEFENSE SYSTEMS</span>
            <span className="hidden md:block text-on-surface-variant opacity-30">|</span>
            <span className="font-mono text-[11px] text-on-surface-variant opacity-60">
              © 2026 Aegis Academy. All rights reserved. System Status: Nominal
            </span>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-[11px] font-mono uppercase tracking-wider">
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors">Security Policy</a>
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors">Incident Response</a>
            <a href="#" className="text-on-surface-variant hover:text-primary transition-colors">Contact Command</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

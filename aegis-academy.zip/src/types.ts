export type AppTab = "landing" | "privacy-module" | "dashboard" | "arena" | "labs" | "status";

export interface UserProfile {
  name: string;
  rank: string;
  level: number;
  xp: number;
  targetXp: number;
  threatLevel: "Low" | "Medium" | "High" | "Critical";
  missionsCompletedCount: number;
  totalMissionsCount: number;
  threatsNeutralized: number;
  neutralizedTrend: string;
  accuracyRating: number; // e.g. 94
  globalRank: number; // e.g. 412
}

export interface Competency {
  name: string;
  percentage: number;
  color: "primary" | "secondary" | "tertiary" | "primary-container";
}

export interface IntelItem {
  id: string;
  type: "info" | "warning" | "success";
  title: string;
  description: string;
  time: string;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  status: "not_started" | "in_progress" | "locked" | "completed";
  difficulty: number; // 1 to 5
  xpReward: number;
  icon: string;
}

export interface CoreModule {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  fullDescription: string;
  estImpact: number; // e.g. 98
}

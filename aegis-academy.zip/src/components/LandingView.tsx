import { useState, useEffect, useRef, FormEvent } from "react";
import { 
  Fingerprint, 
  ShieldCheck, 
  Brain, 
  ArrowRight, 
  Terminal, 
  Shield, 
  Bell, 
  Play, 
  CheckCircle,
  HelpCircle,
  Settings,
  Flame,
  Search,
  Globe,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface LandingViewProps {
  onNavigate: (tab: "landing" | "privacy-module" | "dashboard") => void;
}

export default function LandingView({ onNavigate }: LandingViewProps) {
  // Terminal scanner states
  const [targetUrl, setTargetUrl] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const logContainerRef = useRef<HTMLDivElement | null>(null);

  const initialLogs = [
    "Initializing orbital scan sequence...",
    "Scanning global threat database... [SUCCESS]",
    "Ready for deep packet inspection."
  ];

  const scanStages = [
    "Intercepting handshake packets...",
    "Decoding modern SSL certificate authorities...",
    "Running structural heuristic analysis on host server...",
    "Identifying active scripts and fingerprint models...",
    "Tracing geo-coordinates and network paths...",
    "Probing ports for open databases and vulnerability hooks...",
    "Validating SQL syntax safeguards and CSRF protections...",
    "Analyzing client sandboxing limits and CORS rules...",
    "Heuristics check completed with zero high-severity CVE tags.",
    "✓ SCAN COMPLETE: Target system evaluated as [SECURE]."
  ];

  const handleStartScan = (e: FormEvent) => {
    e.preventDefault();
    if (!targetUrl.trim() || isScanning) return;

    setIsScanning(true);
    setScanProgress(0);
    setLogs([
      "SCAN REQUEST: " + targetUrl,
      "Establishing secure connection tunnel...",
    ]);

    let progress = 0;
    let logIndex = 0;

    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 8) + 3;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setTimeout(() => {
          setIsScanning(false);
        }, 1200);
      }

      setScanProgress(progress);

      // Dynamically push logs based on progress ranges
      const expectedLogCount = Math.floor((progress / 100) * scanStages.length);
      if (logIndex < expectedLogCount && logIndex < scanStages.length) {
        setLogs(prev => [...prev, `> ${scanStages[logIndex]}`]);
        logIndex++;
      }
    }, 120);
  };

  // Auto-scroll terminal logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="relative min-h-screen">
      {/* Hero Section */}
      <section className="relative max-w-7xl mx-auto px-6 md:px-12 text-center pt-8 pb-20">
        <div className="relative inline-block mb-8 group">
          <div className="absolute -inset-4 bg-primary/20 blur-[60px] rounded-full group-hover:bg-primary/35 transition-all duration-700"></div>
          <motion.img 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            alt="Aegis Academy Logo" 
            className="relative w-40 h-40 md:w-56 md:h-56 object-contain mx-auto drop-shadow-[0_0_35px_rgba(164,201,255,0.4)]" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGD5060MHYYXQtJL2-s1geVnUF-MroXZjzHidG4IzjFB0-gpcbjabH9_OnasQ5EIjc9GZE0rX9UGdkCYeMcgMO8NjVaBYmfZnk4uLmx5z3BXqJZPwDxgxUbuEYQu6HXY-o-ePgdaTgROHiFzrIwF4mhLdQ-eiw-dqK0hqeqqMzpRLkt_vPREmyqV0qh9IjIu4Zc9ffY2aEwPeYwQNKcCVAUiwtc17Np8FIjFyKogei70LWim0sK7ZI5sSPGUx5Vh6Xia91V4jUj83c"
          />
        </div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-display text-4xl md:text-7xl font-extrabold leading-[1.1] mb-6 tracking-tight max-w-4xl mx-auto"
        >
          Master Your <br className="md:hidden"/>
          <span className="bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent glow-text">
            Digital Fortress
          </span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="font-sans text-base md:text-lg text-on-surface-variant max-w-2xl mx-auto mb-10 opacity-90 leading-relaxed"
        >
          Forge your skills in the fires of elite cybersecurity training. From zero-day exploits to architectural fortification, become the ultimate guardian of the digital realm.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 md:gap-6"
        >
          <button 
            onClick={() => onNavigate("dashboard")}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-primary to-secondary text-on-primary font-bold text-base shadow-[0_0_25px_rgba(164,201,255,0.25)] hover:scale-105 transition-transform cursor-pointer"
          >
            Enlist Dashboard
          </button>
          <button 
            onClick={() => {
              const el = document.getElementById("modules-catalog");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-xl border border-white/10 hover:border-primary/40 text-primary font-bold text-base hover:bg-primary/5 transition-all cursor-pointer"
          >
            View Course Catalog
          </button>
        </motion.div>
      </section>

      {/* Core Modules Section */}
      <section id="modules-catalog" className="max-w-7xl mx-auto px-6 md:px-12 mb-28">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-4">
          <div>
            <h2 className="font-display text-2xl md:text-3xl font-semibold text-primary mb-2">Core Modules</h2>
            <p className="text-on-surface-variant text-sm md:text-base opacity-80">Strategic specializations for modern operators</p>
          </div>
          <div className="hidden md:block h-px flex-grow mx-8 bg-gradient-to-r from-white/10 via-white/5 to-transparent"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Module 1: Privacy Protection */}
          <div className="glass-card p-6 md:p-8 rounded-2xl flex flex-col justify-between group">
            <div>
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                <Fingerprint className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl md:text-2xl font-semibold text-on-surface mb-3">Digital Identity &amp; Privacy</h3>
              <p className="text-on-surface-variant text-sm md:text-base mb-8 leading-relaxed opacity-85">
                Master advanced anonymization techniques, data sovereignty, and cryptographic identity protection in an age of mass surveillance.
              </p>
            </div>
            <button 
              onClick={() => onNavigate("privacy-module")}
              className="inline-flex items-center text-primary font-bold text-sm hover:translate-x-2 transition-transform text-left cursor-pointer"
            >
              Launch Module <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </div>

          {/* Module 2: Network Fortification */}
          <div className="glass-card p-6 md:p-8 rounded-2xl flex flex-col justify-between group">
            <div>
              <div className="w-14 h-14 rounded-xl bg-secondary/10 flex items-center justify-center text-secondary mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl md:text-2xl font-semibold text-on-surface mb-3">Network Fortification</h3>
              <p className="text-on-surface-variant text-sm md:text-base mb-8 leading-relaxed opacity-85">
                Deploy zero-trust architectures, intrusion detection systems, and deep packet inspection to secure global infrastructure assets.
              </p>
            </div>
            <button 
              onClick={() => onNavigate("dashboard")}
              className="inline-flex items-center text-secondary font-bold text-sm hover:translate-x-2 transition-transform text-left cursor-pointer"
            >
              Launch Simulator <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </div>

          {/* Module 3: Psychological Tactics */}
          <div className="glass-card p-6 md:p-8 rounded-2xl flex flex-col justify-between group">
            <div>
              <div className="w-14 h-14 rounded-xl bg-tertiary/10 flex items-center justify-center text-tertiary mb-6 group-hover:scale-110 transition-transform">
                <Brain className="w-8 h-8" />
              </div>
              <h3 className="font-display text-xl md:text-2xl font-semibold text-on-surface mb-3">Psychological Tactics</h3>
              <p className="text-on-surface-variant text-sm md:text-base mb-8 leading-relaxed opacity-85">
                Understand the human element of security through cognitive bias analysis, pretexting, and defensive communication protocols.
              </p>
            </div>
            <button 
              onClick={() => {
                const el = document.getElementById("terminal-widget-container");
                if (el) el.scrollIntoView({ behavior: "smooth" });
              }}
              className="inline-flex items-center text-tertiary font-bold text-sm hover:translate-x-2 transition-transform text-left cursor-pointer"
            >
              Scan Systems <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </div>
        </div>
      </section>

      {/* Interactive Terminal Widget */}
      <section id="terminal-widget-container" className="max-w-4xl mx-auto px-4 mb-28">
        <div className="relative">
          <div className="absolute -inset-4 bg-primary/10 blur-3xl opacity-40 rounded-3xl pointer-events-none"></div>
          <div className="relative rounded-xl overflow-hidden border border-white/10 shadow-2xl">
            {/* Header */}
            <div className="bg-surface-container-highest px-6 py-3 flex items-center justify-between border-b border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-error"></div>
                <div className="w-3 h-3 rounded-full bg-tertiary"></div>
                <div className="w-3 h-3 rounded-full bg-primary-container"></div>
                <span className="ml-4 font-mono text-xs text-on-surface-variant opacity-60">AEGIS_SENTINEL_V4.2.0</span>
              </div>
              <span className="font-mono text-xs text-primary font-semibold tracking-wider">CONNECTED // OSC_01</span>
            </div>

            {/* Terminal Content */}
            <div className="bg-black/90 p-6 md:p-8 min-h-[380px] font-mono text-sm relative overflow-hidden flex flex-col justify-between">
              <div className="scan-line absolute inset-x-0 top-0 opacity-10 pointer-events-none"></div>
              
              {/* Output log */}
              <div ref={logContainerRef} className="flex-grow space-y-2 mb-6 max-h-[220px] overflow-y-auto scrollbar-thin">
                {initialLogs.map((log, index) => (
                  <p key={index} className="text-on-surface-variant opacity-75">{log}</p>
                ))}
                
                {logs.map((log, index) => {
                  const isSuccess = log.includes("✓ SCAN COMPLETE");
                  const isRequest = log.includes("SCAN REQUEST");
                  return (
                    <p 
                      key={index} 
                      className={isSuccess ? "text-primary font-bold" : isRequest ? "text-secondary font-semibold" : "text-on-surface-variant"}
                    >
                      {log}
                    </p>
                  );
                })}

                {isScanning && (
                  <div className="pt-2">
                    <div className="flex justify-between items-center text-primary-fixed mb-1">
                      <span>ANALYZING THREAT PACKETS...</span>
                      <span>{scanProgress}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-150 rounded-full"
                        style={{ width: `${scanProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input section */}
              <form onSubmit={handleStartScan} className="relative border-t border-white/10 pt-6">
                <label className="block text-primary/60 text-[10px] uppercase tracking-widest mb-2 font-semibold">
                  TARGET_URL_IDENTIFIER
                </label>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative flex-grow">
                    <input 
                      disabled={isScanning}
                      value={targetUrl}
                      onChange={(e) => setTargetUrl(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 py-3 text-primary focus:outline-none focus:border-primary/50 transition-all font-mono text-sm placeholder:text-on-surface-variant/40" 
                      id="terminal-input" 
                      placeholder="https://secure.aegis.academy/threat-intel" 
                      type="text"
                    />
                    <Globe className="w-4 h-4 text-on-surface-variant absolute left-3.5 top-3.5 opacity-60" />
                  </div>
                  <button 
                    type="submit"
                    disabled={isScanning || !targetUrl.trim()}
                    className={`px-8 py-3 bg-primary text-on-primary font-bold rounded-lg transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer ${(!targetUrl.trim() || isScanning) ? "opacity-50 cursor-not-allowed" : "hover:shadow-[0_0_15px_rgba(164,201,255,0.4)]"}`}
                  >
                    <Terminal className="w-4 h-4" />
                    <span>SCAN</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
